<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const email = ref('');
const password = ref('');

const handleLogin = () => {
    if (!email.value || !password.value) {
        alert("Vui lòng nhập email và mật khẩu!");
        return;
    }

    // Lưu thông tin giả lập
    const userData = {
        name: "Người dùng mẫu", // Hoặc lấy từ email
        email: email.value
    };
    localStorage.setItem('currentUser', JSON.stringify(userData));

    // Đóng Modal an toàn
    const modalElement = document.getElementById('modalLogin');
    if (modalElement) {
        const bootstrapInstance = window.bootstrap || bootstrap;
        const modalInstance = bootstrapInstance.Modal.getInstance(modalElement);
        if (modalInstance) {
            modalInstance.hide();
        } else {
             new bootstrapInstance.Modal(modalElement).hide();
        }
    }

    // Chuyển hướng
    alert("Đăng nhập thành công!");
    router.push('/home-user');
}
</script>

<template>
    <div class="modal fade" id="modalLogin" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Đăng nhập</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input v-model="email" type="email" class="form-control" placeholder="Nhập email">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Mật khẩu</label>
                            <input v-model="password" type="password" class="form-control" placeholder="Nhập mật khẩu">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                    <button type="button" class="btn btn-success" @click="handleLogin">Đăng nhập</button>
                </div>
            </div>
        </div>
    </div>
</template>