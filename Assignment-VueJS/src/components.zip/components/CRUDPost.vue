<script setup>

</script>
<template>
    <div class="container mt-4">
        <div class="card" style="width: 800px;">
            <div class="card-body">
                <h4>Đăng bài viết</h4>
                <div class="mb-3">
                    <input class="form-control" placeholder="Tiêu đề">
                </div>
                <div class="mb-3">
                    <textarea class="form-control mb-2" rows="5" placeholder="Nội dung"></textarea>
                </div>
                <input type="file" class="form-control mb-2" />
                
                <button class="btn btn-outline-info mb-3">Đăng bài</button>
            </div>
        </div>
    </div>
</template>