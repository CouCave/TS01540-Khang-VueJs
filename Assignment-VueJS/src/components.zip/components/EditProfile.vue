<script setup>

</script>
<template>
    <div class="container mt-4">
        <div class="card" style="width: 400px;">
            <div class="card-body">
                <form>
                    <div class="container mt-4" style="max-width:600px">
                        <h3>Thông tin cá nhân</h3>
                        <input class="form-control mb-2" placeholder="Họ tên" />
                        <input class="form-control mb-2" placeholder="Email" />
                        <input type="password" class="form-control mb-2" placeholder="Mật khẩu mới" />
                        <button class="btn btn-outline-success">Cập nhật</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>